/*
  # Fix Database Schema

  1. New Tables
    - events
    - digital_marketing_campaigns
    - products (updated schema)
    
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create events table
CREATE TABLE IF NOT EXISTS events (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    event_date TIMESTAMPTZ NOT NULL,
    location TEXT NOT NULL,
    capacity INTEGER NOT NULL CHECK (capacity > 0),
    created_at TIMESTAMPTZ DEFAULT now()
);

-- Create digital_marketing_campaigns table
CREATE TABLE IF NOT EXISTS digital_marketing_campaigns (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    status VARCHAR(50) NOT NULL,
    lander_ready_deadline DATE NOT NULL,
    advisor_name VARCHAR(255) NOT NULL,
    group_name VARCHAR(255) NOT NULL,
    campaign_start DATE NOT NULL,
    campaign_end DATE NOT NULL,
    ideal_budget DECIMAL(12, 2),
    max_budget DECIMAL(12, 2),
    landing_page_url TEXT,
    privacy_company_website TEXT,
    privacy_company_name VARCHAR(255),
    creatives_made BOOLEAN DEFAULT FALSE,
    creatives_in_google_drive BOOLEAN DEFAULT FALSE,
    tech_lander_ready BOOLEAN DEFAULT FALSE,
    hyros_tracking_ready BOOLEAN DEFAULT FALSE,
    campaign_running BOOLEAN DEFAULT FALSE,
    campaign_completed BOOLEAN DEFAULT FALSE,
    disclaimer TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- Update products table
DROP TABLE IF EXISTS products CASCADE;
CREATE TABLE products (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    amount DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE digital_marketing_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow authenticated users to view events"
    ON events FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow authenticated users to view campaigns"
    ON digital_marketing_campaigns FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow authenticated users to view products"
    ON products FOR SELECT TO authenticated USING (true);

-- Insert sample data
INSERT INTO events (title, description, event_date, location, capacity) VALUES
    ('Retirement Planning Seminar', 'Learn essential strategies for a secure retirement', now() + interval '7 days', 'Grand Hotel Conference Center', 50),
    ('Estate Planning Workshop', 'Comprehensive workshop on estate planning', now() + interval '14 days', 'Financial District Meeting Hall', 30),
    ('Investment Strategies Symposium', 'Advanced investment techniques for advisors', now() + interval '21 days', 'Business Center Auditorium', 100);

INSERT INTO digital_marketing_campaigns (
    status, lander_ready_deadline, advisor_name, group_name, 
    campaign_start, campaign_end, ideal_budget, max_budget, campaign_running
) VALUES
    ('Active', '2025-02-15', 'John Smith', 'Retirement Planners', '2025-02-01', '2025-03-01', 5000.00, 6000.00, true),
    ('Active', '2025-02-20', 'Sarah Johnson', 'Financial Advisors Group', '2025-02-10', '2025-03-10', 4000.00, 4800.00, true),
    ('Active', '2025-02-25', 'Michael Brown', 'Wealth Management Team', '2025-02-15', '2025-03-15', 6000.00, 7200.00, true);

INSERT INTO products (name, description, amount) VALUES
    ('Digital campaign', 'Full Digital Marketing Campaign', 4500.00),
    ('E-mail marketing service', 'Email Marketing Campaign', 300.00),
    ('Omnichannel Marketing', 'Omnichannel Marketing Package', 840.00);